# Phase 4: wireframes

Source: Claude Code (VS Code) session `ce5f2d70-e638-45e6-8e93-000aff809da9`.
Started: 2026-10-12 03:33 UTC.

## Student — 2026-10-12 03:33

Use the student-build skill. Phase 4. Wireframe images are in docs/wireframes/.

### Guide

I'll start by loading the course skill files, the current report, and the wireframes.

_tool: Bash — List skill/docs files and read skill instructions_

_tool: Read — c:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

_tool: Read — C:\Users\suare\.claude\projects\c--Users-suare-OneDrive-Documents-GitHub-Comp3613-A1\ce5f2d70-e638-45e6-8e93-000aff809da9\tool-results\bb3r9gf43.txt_

_tool: Read — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\wireframes\wireframes.png_

_tool: Bash — Read use-case diagram source_

**student-build, Phase 4.** You have **3 skips**. This chat covers Phase 4 only; Phase 5 starts in a new chat.

I checked `docs/wireframes/wireframes.png` against the Phase 2 use cases and the Phase 3 ERD.

**Coverage**

| Use case | Image | Covered |
|---|---|---|
| Submit Application (Student) | Student dashboard (no application) → Application form → Student dashboard (with application) → Edit application | yes |
| View Application Status (Student) | "My application / Status" card on the student dashboard | yes |
| Match Application to Internship (Admin) | Admin dashboard → Match Application → Internship Details | yes |
| Check Requirements | "Eligible Internships" list on Match Application | yes |
| Publish/Manage Internships (Company) | Company dashboard → Internship Form, plus close / edit / view matches | yes |
| Log In, Register with University Email | No image. I'm assuming these reuse the starter login and register screens and get themed in Phase 5. | yes (starter) |
| **Create Company Account (Admin)** | **No image** | **no** |
| **Reject Application (No Suitable Internship)** | **No image, and the Match Application screen has no reject action** | **no** |

**Create Company Account has no wireframe.** Companies can't register themselves, so without this screen no Company user can log in, and Publish/Manage Internships can't start. Please add an image for it to `docs/wireframes/`. I'll wait for that before moving on to the model suggestions.

While you do that, one question about the other gap:

**On the Match Application screen, what does the Admin do when none of the eligible internships fit (or the list is empty)? Where do they reject the application, and what happens next?**

You can answer that in words, or show it in the new image if it's easier to draw.

## Student — 2026-10-12 03:42

check now

### Guide

_tool: Bash — List wireframe files_

Same single file, updated recently. Re-reading it.

_tool: Read — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\wireframes\wireframes.png_

The updated image covers both gaps:

- **Create Company Account:** the "add company" button in the admin sidebar opens a modal. The modal's fields aren't drawn, so I'll use the ERD fields: `USER` username, email and password with role `company`, plus `COMPANY` company_name, contact_email and industry. You don't need to redraw it.
- **Reject Application:** the Match Application screen now has a **reject** button. I'll assume it sets `APPLICATION.status = rejected`, sends the Admin back to the unmatched list, and shows "Status: rejected" on the student's dashboard.

Every use case now has an image. Log In and Register reuse the starter screens.

**Model suggestion so far**

- `APPLICATION.cover_statement`: remove it? It isn't on the Application form or the Edit application screen.

**Design notes** (nothing to redraw)

- The admin header has **Students** and **Internship** buttons, but no image shows where they go and no use case needs them. In Phase 5 we'll either drop them or point them at simple lists.
- The company card has only **close** and **edit**. The Phase 3 rule said an internship with no matches can be deleted, but no delete action is drawn.

**Next question (2/5):** The student dashboard shows a single "My application" card, and the Submit button disappears once an application exists. Does a student get only one application, or can they submit a new one later, for example after being rejected? Phase 3 assumed one student could have many applications, so your answer decides whether `APPLICATION.student_id` becomes unique.

## Student — 2026-10-12 03:44

those buttons change what you see in the dashboard, in tha tone youre seeing the students if you click internship it shows the internships

### Guide

Got it. The **Students** / **Internship** buttons switch the admin dashboard between two views:

- **Students:** the application cards with the "unmatched applications" filter and search, as drawn.
- **Internship:** a list of internships. No image shows it, so in Phase 5 I'll reuse the company card layout (title, number of positions, deadline) and add the company name and open/closed status. Both are already in the ERD.

That's a dashboard toggle, not an extra screen, so the note is resolved.

**Question 2/5 is still open:** the student dashboard shows one "My application" card, and the Submit button disappears once an application exists. Is it **one application per student**, or can a student submit a **new one later**, for example after being rejected?

## Student — 2026-10-12 03:46

keep one application per student If it’s rejected manage application shows up again, the student edits it, clicks resubmit, and the status goes back to Submitted so the admin sees it again

### Guide

Recorded:

- **Student → Application becomes one-to-one.** `APPLICATION.student_id` is unique.
- **Resubmit after rejection:** when the status is `rejected`, the "manage application" button shows again. Resubmitting sets the status back to `submitted`, and the application returns to the Admin's unmatched list.
- **My assumption:** while the status is `submitted` the student can still edit through manage application, and resubmitting doesn't change the status. Once the status is `matched`, the application is locked because the match is final.

**Question 3/5:** The dashboard card only shows "Status: …". Once the status is **matched**, what does the student see? Does the card show which internship and company they were placed with, or only the word "matched"?

## Student — 2026-10-12 03:47

When the status is matched, the card shows the internship title, the company name, and the location, so the student knows where they were placed

### Guide

That doesn't need new fields. Title and location come from `MATCH → INTERNSHIP`, and the company name comes from `INTERNSHIP → COMPANY`. I'll note it as a display rule for the matched status.

**Question 4/5:** The Application form asks for Name, ID, Email, Program, Year and GPA, but in the ERD those live on `STUDENT` (and email on `USER`), not on `APPLICATION`. Register only collects the university email and password. Which of these do you want?

- **A.** The Application form creates and updates the student's `STUDENT` profile. Editing GPA on resubmit changes the profile itself.
- **B.** Copy those values onto `APPLICATION` as a snapshot, so the Admin sees what was submitted and the profile stays separate.
- **C.** Something else.

## Student — 2026-10-12 03:47

a

### Guide

Going with **A**:

- Submitting the Application form for the first time **creates** the student's `STUDENT` row (full_name, student_id, program, year_of_study, gpa). Edit and resubmit **update** that same row. `APPLICATION` keeps only `preferences`, `projects`, `submitted_date` and `status`.
- **My assumption:** the form's email field is filled in from `USER.email` and can't be edited, because it's the university email the student registered with.

**Question 5/5, last one.** Which of these model revisions should I apply? Pick any or all:

1. Remove `APPLICATION.cover_statement`. It isn't on any form.
2. Make `APPLICATION.student_id` unique, so Student → Application is one-to-one, per your answer.
3. Drop **delete internship**, so companies only **close**, matching the wireframe card. Otherwise I keep the Phase 3 rule and add a delete action in Phase 5 for internships with no matches.

## Student — 2026-10-12 03:48

apply the 3

### Guide

Applying all three to `docs/report.md`, and embedding the wireframe with the coverage blocks.

_tool: Bash — Apply Phase 4 model revisions and embed wireframes in report_

Phase 4 is done. All three model changes are applied, and the wireframe is embedded in [docs/report.md](docs/report.md) with a coverage note for each use case.

**Model changes**
- **Cover statement removed:** `APPLICATION.cover_statement` is gone, since it isn't on any form.
- **One application per student:** `APPLICATION.student_id` is now unique, and the diagram shows `STUDENT ||--o| APPLICATION`.
- **Close only:** companies can no longer delete an internship. The old Phase 3 delete rule is marked as replaced.

**Workflow decisions written to the report**
- **Application form and profile:** the form creates the student's profile on the first submit, and editing or resubmitting updates that same profile.
- **Rejected applications:** a rejected application can be edited and resubmitted. It goes back to "submitted" and returns to the Admin's unmatched list.
- **Matched applications:** once matched, the application is locked, and the card shows the internship title, company name and location.
- **Admin dashboard:** the Students and Internship buttons switch between the application cards and an internship list.
- **Reject and add company:** the reject button and the "add company" pop-up form are included as drawn.

**What I assumed rather than asked** (also noted in the report):
- The email field on the form is filled in from the registered email and can't be edited.
- A student can still edit while the status is "submitted".
- Reject sends the Admin back to the dashboard.
- The "add company" form uses the account and company fields from the model.
- Log In and Register use the starter screens, which get themed in Phase 5.

```text
Phase 4 done
Artefact: docs/report.md (+ docs/wireframes/wireframes.png)
Base confidence: 0.75
Questions: 5/5
Suspicion: none
Skips: 0/3 used
Report: updated
```

Your progress is saved in `docs/report.md`, not only in this chat. Open a **new chat** and paste this, filling in your preferences:

```text
Use the student-build skill. Phase 5. Wireframes are in docs/wireframes/. Here are theming and branding preferences: …
```

