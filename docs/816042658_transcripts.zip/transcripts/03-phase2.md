# Phase 2: use-case diagram

Source: Claude Code (VS Code) session `d39db66a-d0e4-400e-b59b-7f5bf9b76d31`.
Started: 2026-10-05 16:52 UTC.

## Student — 2026-10-05 16:52

Use the student-build skill. Phase 2. Here is my Phase 1 artefact in docs/report.md. Draft the use-case diagram from it.

### Guide

I'll load the course skill and your Phase 1 artefact first.

_tool: Bash — List skill/docs files and read the student-build skill_

_tool: Bash — Read the report and existing use-case JSON_

_tool: Read — C:\Users\suare\.claude\projects\c--Users-suare-OneDrive-Documents-GitHub-Comp3613-A1\d39db66a-d0e4-400e-b59b-7f5bf9b76d31\tool-results\bg7npvp3g.txt_

_tool: Bash — Read Phase 2 rules and the Internship Platform brief_

**student-build loaded: Phase 2, the use-case diagram.**

- You have **3 skips** for questions you think are needless. Skips: 0/3 used.
- This chat covers Phase 2 only. Once the diagram is drafted, open a **new chat** for Phase 3.
- The Phase 1 artefact has the project (Internship Platform) and four workflows with three actors: Company, Student and Admin.

Base confidence is **0.65**, so I can ask at most **6** questions before I draft. I'll ask them one at a time.

**Question 1 of 6:**

Here are your four use cases:

1. Publish/Manage Internships (Company)
2. Submit Application (Student)
3. Match Application to Internship (Admin)
4. Review Application (Company)

Should any of these **«include»** or **«extend»** another, or contain a sub-step that should, instead of standing alone with its own actor line? For each pair you pick, say whether the step is **always** required («include») or **only sometimes** («extend»).

## Student — 2026-10-05 16:55

match application should include check requirements cause the system always checks the student's GPA, program and year against the internship's requirements before making a match. review application

### Guide

Noted: **Match Application to Internship «include» Check Requirements.** The system always checks GPA, program and year against the internship's requirements before it makes a match.

Your message stops at "review application", so I don't have the rest of that answer. What did you want for **Review Application (Company)**? Does it «include» or «extend» something, or does it relate to another use case such as Match Application? Please say whether that step happens **always** or **only sometimes**.

I'm still counting this as **question

## Student — 2026-10-05 16:55

[Request interrupted by user]

## Student — 2026-10-05 16:56

match application should include check requirements cause the system always checks the student's GPA, program and year against the internship's requirements before making a match.

### Guide

Recorded: **Match Application to Internship «include» Check Requirements** (always runs). Review Application stays as its own use case with no include or extend. Questions: 1/6.

**Question 2 of 6:**

You named **Submit Application (Student)**, but nothing that lets a student see which internships exist. How does a student find the posting they're applying to, and check its details and requirements, before they submit?

## Student — 2026-10-05 16:58

in this design the student does not apply to a specific internship, they apply and the system after review their application if accepted matches them with internships

### Guide

Recorded: students apply to a **general pool**, not to a specific posting, so the diagram doesn't need a Browse Internships use case. Questions: 2/6.

**Question 3 of 6:**

That leaves an ordering question between two of your use cases. **Review Application** belongs to the Company, and **Match Application to Internship** belongs to the Admin. If a student's application isn't aimed at any one company, which company reviews it, and does that review happen **before** the Admin matches it or **after**, once it has been matched to that company's internship?

## Student — 2026-10-05 17:00

The company reviews it only after the admin has matched it. Until a match is made, the application belongs to no company and only the admin can see it once the admin matches a student to an internship, that application shows up in review application for the company that posted it, and the company decides whether to accept or reject the student

### Guide

Recorded: the order is **Submit → Admin Match (includes Check Requirements) → Company Review (accept/reject)**. Before a match, only the Admin can see an application, and after the match it belongs to the company that posted the internship. Questions: 3/6.

**Question 4 of 6:**

What happens when the company **rejects** a matched student? Does the application end there, or does it go back to the Admin to be matched to a different internship? If it goes back, does that happen **every time** or **only sometimes**, for example only while there are other internships the student still qualifies for?

## Student — 2026-10-05 17:04

If a company rejects the student, the application goes back to the admin. If there are still internships available and the student is suitable for one, the admin matches the application to that new company. If not, the student is rejected.

### Guide

Recorded. A rejection is **conditional**, so I'll draw it as an «extend» on Review Application that sends the application back to the Admin. If no other suitable internship is left, Match Application ends in the student being rejected, which is also an «extend». Questions: 4/6.

**Question 5 of 6:**

Under this design the student submits once and then the application moves through Admin match, Company review, and possibly a re-match. None of your use cases shows the student any of that. How does a student find out whether they were matched, accepted or rejected?

## Student — 2026-10-05 17:05

The student finds out through a new use case  view application status

### Guide

Recorded: a new use case, **View Application Status (Student)**. Questions: 5/6.

**Question 6 of 6 (the last before I draft):**

All three actors work in protected flows. The starter app lets anyone register, but a company that posts internships is a trusted party. How does a **Company** account come to exist? Does the company register itself, or does the Admin create or approve it? And do students simply register and log in?

## Student — 2026-10-05 17:07

Students register with their university email  so only enrolled students can create accounts. Companies cannot register themselves. The admin creates each company account after the company is approved to take part, so only trusted companies can post internships

### Guide

That's all six questions. I'll check how the renderer reads `includes`/`extends` and actor sides before I write the JSON.

_tool: Bash — Find the use-case renderer and its JSON handling_

_tool: Bash — Inspect renderer handling of extends, includes and sides_

_tool: Bash — Check default actor linking for use cases_

_tool: Write — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\diagrams\use-case.json_

_tool: Bash — Render the use-case diagram PNG_

The command picked up an `app` package from a different project (`info2602-fastapi-l4`). I'll check where that path comes from.

_tool: Bash — Check Python path and virtualenv setup_

The global Python has an editable install of another project that takes over the name `app`. I'll use this project's `venv` instead.

_tool: Bash — Render the diagram with the project virtualenv_

_tool: Read — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\diagrams\use-case.png_

The PNG rendered and it reads correctly. Next I'll add the embed and notes to the report.

_tool: Edit — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

I've drafted the use-case diagram from your Phase 1 workflows and your six answers. It's saved as [use-case.png](docs/diagrams/use-case.png), built from [use-case.json](docs/diagrams/use-case.json), and embedded in [report.md](docs/report.md) with notes on each decision.

**What's on the diagram:**
- **Student:** Register with University Email, Log In, Submit Application, View Application Status.
- **Company:** Log In, Publish/Manage Internships, Review Application.
- **Admin:** Log In, Create Company Account, Match Application to Internship.
- **«include»:** Match Application to Internship always includes Check Requirements (GPA, program and year).
- **«extend»:** Return Application to Admin extends Review Application, and only happens when the company rejects the student.
- **«extend»:** Reject Application (No Suitable Internship) extends Match Application to Internship, and only happens when no internship fits.

Two things I decided without asking:
- **Log In is one use case shared by all three actors.** The alternative was a separate login line from every protected use case, which would clutter the diagram.
- **Student is drawn across the top, not on the left.** I asked for Student on the left and Company and Admin on the right, but the renderer moved Student. Company and Admin still end up on opposite sides, and the diagram reads fine.

`python manage.py run` won't work with the plain `python` command in this project. Your global Python has an editable install from another project that also uses the name `app`, so it loads the wrong code. I ran the course command with `./venv/Scripts/python.exe manage.py usecase` instead, so activate `venv` before you use `manage.py`.

```text
Phase 2 done
Artefact: docs/report.md (+ docs/diagrams/use-case.json, docs/diagrams/use-case.png)
Base confidence: 0.65
Questions: 6/6
Suspicion: none
Skips: 0/3 used
Report: updated
```

Your progress is saved in `docs/report.md`, not just in this chat. Open a **new chat** and paste this, along with your list of entities and their properties:

```text
Use the student-build skill. Phase 3. Here are my entities and properties. Draft the model diagram from docs/report.md.
```

## Student — 2026-10-12 02:46

can you remove the review application pne?

### Guide

_tool: Read — c:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

**Guide asked:** Review Application is your 4th named workflow, and your Phase 3 model relies on it: the company accepts or rejects each Match, and a rejection sends the application back to the Admin. If it's removed, who decides whether a matched student is accepted?

## Student — 2026-10-12 02:46

_(answer)_ The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). STOP what you are doing and wait for the user to tell you how to proceed.

## Student — 2026-10-12 02:46

[Request interrupted by user for tool use]

## Student — 2026-10-12 03:00

admins match is final

### Guide

I'll take Review Application out of the workflows, the diagram and the model notes.

_tool: Bash — Remove Review Application from the diagram JSON and re-render_

Now the report: workflows list, Phase 2 notes, and the model parts that relied on company review.

_tool: Bash — Update report to remove Review Application and its model effects_

_tool: Read — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\diagrams\use-case.png_

I removed Review Application, and the Admin's match is now final. The re-rendered [use-case.png](docs/diagrams/use-case.png) has no Review Application and no Return Application to Admin. Match Application still includes Check Requirements, and Reject Application (No Suitable Internship) still extends it.

**Changes in [report.md](docs/report.md):**
- **Workflows:** there are now three, which is still the minimum. A one-line note says why the fourth was dropped.
- **Phase 2 notes:** I removed the Return Application extend line. The notes now say companies don't review or reject matches, and View Application Status shows matched or rejected.
- **Model:** I removed `MATCH.status` and the `accepted` value of `APPLICATION.status`. These model edits follow from your decision; you didn't name them yourself.
- **Model notes:** the Phase 3 notes about company rejection and re-matching are gone. Every match now counts toward `number_of_positions`, and a company can't delete an internship that has matches because those are students' final placements. A revision note records all of this.

Two things are still open, and I haven't changed either:
- **Application → Match is still drawn one-to-many.** Since a match is final, an application can only ever have one. Do you want it changed to one-to-one, with a unique `application_id` on Match?
- **The Company has no way to see which students were matched to its internships.** Publish/Manage Internships is now its only workflow. Is that intended, or should the company be able to see its matched students?

Skips: 0/3 used.

## Student — 2026-10-12 03:03

yes cahnge to one to one, the company should be able to see its matched students, but as part of publish/manage

### Guide

_tool: Bash — Make Application-Match one-to-one and note company's matched-students view_

I made both changes in [report.md](docs/report.md):

- **One-to-one:** the model diagram now shows Application to Match as `APPLICATION ||--o| MATCH`, and `MATCH.application_id` is marked FK, UK (a foreign key that must be unique). I rewrote the relationship note to match, and the revision note records the change from one-to-many.
- **Matched students:** a new Phase 2 note says a company sees the students matched to its internships as part of Publish/Manage Internships. You said it belongs inside that use case, so I didn't add a separate one, and the use-case diagram stays as it is.

Skips: 0/3 used. Your design phases now go up to the model. When you're ready, open a **new chat** for Phase 4 with your wireframe images in `docs/wireframes/`:

```text
Use the student-build skill. Phase 4. Wireframe images are in docs/wireframes/.
```

When you draw Publish/Manage Internships, include where the company sees its matched students, because Phase 4 checks that each use case is shown in an image.

