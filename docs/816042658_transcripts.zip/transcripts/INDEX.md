# Session transcripts

Filled by the **Guide agent** (Copilot Agent, Cursor, or OpenCode) when
building the report — one markdown file per Guide chat for this project.
`python manage.py report` only packages these files; it does not scrape an IDE.

Chats packaged: **9**

| Chat | File |
| --- | --- |
| `01-setup` | [01-setup.md](01-setup.md) |
| `02-phase1` | [02-phase1.md](02-phase1.md) |
| `03-phase2` | [03-phase2.md](03-phase2.md) |
| `04-phase3` | [04-phase3.md](04-phase3.md) |
| `05-phase4` | [05-phase4.md](05-phase4.md) |
| `06-phase5` | [06-phase5.md](06-phase5.md) |
| `07-phase5-wrapup-render-setup` | [07-phase5-wrapup-render-setup.md](07-phase5-wrapup-render-setup.md) |
| `08-phase6` | [08-phase6.md](08-phase6.md) |
| `09-phase6-deploy` | [09-phase6-deploy.md](09-phase6-deploy.md) |
