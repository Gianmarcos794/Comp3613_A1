# Phase 1: project and workflows

Source: Claude Code (VS Code) session `bb707d48-39ab-47a3-b422-0c4ee66ec423`.
Started: 2026-10-05 16:49 UTC.

## Student — 2026-10-05 16:49

start the assignment using the build skill

### Guide

I'll load the course skill files first.

_tool: Bash — Read student-build skill and phases doc_

_tool: Read — C:\Users\suare\.claude\projects\c--Users-suare-OneDrive-Documents-GitHub-Comp3613-A1\bb707d48-39ab-47a3-b422-0c4ee66ec423\tool-results\bp3otnz4v.txt_

Now let me check where the project stands and the assignment briefs.

_tool: Bash — Read report, wireframes, and assignment brief_

**student-build** is loaded, and you're at **Phase 1**: `docs/report.md` is still the blank template and `docs/wireframes/` is empty.

How this works:
- **Each chat covers one design phase.** When Phase 1 is done, I'll write it into `docs/report.md`, stop, and give you the prompt to start Phase 2 in a **new chat**. Phase 5 (theme → build → polish) can stay in one chat for all workflows, and Phase 6 is deployment, which comes after polish.
- **You have 3 skips.** If a question feels too hard or pointless, say **skip**. I'll make a stated assumption and move on. A skip can't stand in for your project choice, your workflow names or your wireframes.
- **No app code until Phase 5.**

For this phase, base confidence is below 0.40 because nothing is written yet, so I can ask at most 8 questions.

---

**Question 1: Which project were you assigned on the myeLearning spreadsheet?**

1. **Alumni App:** a CRM for staying connected with graduates (profiles, events, networking)
2. **Internship Platform:** student applications matched to company internship positions
3. **MyAdvisor:** degree progress, semester course planning, advisor approval
4. **Research Platform:** poster and presentation submissions, review, and status through the event lifecycle
5. **Student Awards:** volunteer hours, a leaderboard, milestones and prize redemption
6. **Student Accommodation:** an Airbnb-like marketplace with listings, reviews, and tenant and booking management

You can also list your workflows now if you have them. Use at least three lines in this format:

```text
Feature (user)
```

For example: `Explore/Search Publications (Public)`. You only need names here. The screen steps go in your Phase 4 wireframes.

## Student — 2026-10-05 16:50

2

### Guide

Internship Platform it is. That's one question used (1/8).

**Question 2: What are your workflows for the Internship Platform?**

Name at least three, one per line, in this format:

```text
Feature (user)
```

For example: `Explore/Search Publications (Public)`. Each user in brackets is the person or role who does that workflow. Three is the minimum, and you can name more. Names are enough here: the steps go in your Phase 4 wireframes.

## Student — 2026-10-05 16:52

publish\manage internships(company)  submit application(student) match application to internship(admin) review application(company)

### Guide

_tool: Edit — C:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

I recorded your four workflows in [docs/report.md](docs/report.md) under **Assigned project** and the workflows section. I only tidied the capitalisation and the slash:

1. Publish/Manage Internships (Company)
2. Submit Application (Student)
3. Match Application to Internship (Admin)
4. Review Application (Company)

Each one already says who does it, so Phase 1 needs nothing more.

```text
Phase 1 done
Artefact: docs/report.md
Base confidence: 0.30
Questions: 2/8
Suspicion: none
Skips: 0/3 used
Report: updated
```

Your progress is saved in `docs/report.md`, so the next chat can pick it up from there. **Open a new chat** and paste this to start Phase 2:

```text
Use the student-build skill. Phase 2. Here is my Phase 1 artefact in docs/report.md. Draft the use-case diagram from it.
```

