# Phase 3: model diagram

Source: Claude Code (VS Code) session `fcd78062-4fdb-4e37-8a85-ed56ceae84f5`.
Started: 2026-10-05 17:08 UTC.

## Student — 2026-10-05 17:08

Use the student-build skill. Phase 3. Here are my entities and properties. Draft the model diagram from docs/report.md.

### Guide

_tool: Bash — Read skill files and report_

_tool: Read — C:\Users\suare\.claude\projects\c--Users-suare-OneDrive-Documents-GitHub-Comp3613-A1\fcd78062-4fdb-4e37-8a85-ed56ceae84f5\tool-results\bt4wzipu8.txt_

I'm using **student-build** for **Phase 3, the model diagram**. A few rules for this chat:

- You have **3 skips** for questions that seem too hard or pointless. When you skip one, I'll make a reasonable assumption and keep going.
- This chat covers **only Phase 3**. Phase 4 starts in a new chat.
- Skipping can't be used for the entity list. You have to name the entities and their properties yourself.

I read `docs/report.md`. Phase 1 and Phase 2 are there: the Internship Platform, four workflows, and the use-case diagram with its include/extend decisions. Your entities and properties aren't in the report or in your message yet, so I'll start there. After that I'll ask about relationships and business rules, and then draft the `erDiagram`.

**Question 1: Which entities does the model need, and which properties does each one have?**

Type them in this shape:

```text
Internship
- title
- ...
Student
- ...
```

## Student — 2026-10-05 17:56

```
User
- username
- email
- password
- role (student, company, admin)

Student
- user
- full name
- student id
- program
- year of study
- gpa

Company
- user
- company name
- contact email
- industry

Internship
- company
- title
- description
- location
- required program
- minimum gpa
- minimum year
- number of positions
- deadline
- status (open, closed)

Application
- student
- preferences
- cover statement
- submitted date
- status (submitted, matched, accepted, rejected)

Match
- application
- internship
- matched date
- status (pending, accepted, rejected)
```

## Student — 2026-10-05 17:56

[Request interrupted by user]

## Student — 2026-10-05 17:57

```
User
- username
- email
- password
- role (student, company, admin)

Student
- user
- full name
- student id
- program
- year of study
- gpa

Company
- user
- company name
- contact email
- industry

Internship
- company
- title
- description
- location
- required program
- minimum gpa
- minimum year
- number of positions
- deadline
- status (open, closed)

Application
- student
- preferences
- cover statement
- submitted date
- status (submitted, matched, accepted, rejected)

Match
- application
- internship
- matched date
- status (pending, accepted, rejected)
```

### Guide

Thanks, that list works. I'll use your entities and properties as written. Next come the relationships and business rules. These are the questions left before I draft (up to 5 more).

In Phase 2 you decided that a company can reject a student, and then **Return Application to Admin** lets the Admin re-match the same application to a different internship.

**Question 2: How are Application and Match related: one-to-one, or one-to-many (one application can have several Match rows over time)? Which of the two holds the foreign key?**

## Student — 2026-10-05 18:00

Application and Match are one-to-many. One application can have several Match rows over time, one for each internship the admin matches it to, because a rejected application goes back to the admin and can be matched again. Match holds the foreign key, since each Match row stores the application it belongs to.

### Guide

Good. One-to-many with the FK on Match fits re-matching, and it also keeps a history of earlier rejections.

**Question 3: On Application, what is `preferences`? Is it free text (for example, "prefer software roles in Port of Spain"), or does the student rank specific internships? Ranking specific internships would mean a relationship between Application and Internship.**

## Student — 2026-10-05 18:01

Preferences is free text. The student writes what they are looking for

### Guide

That works with the general pool from Phase 2. Students don't pick internships, so there's no link between Application and Internship except through Match.

**Question 4: Can one application have more than one Match with status `pending` (or `accepted`) at the same time? For example, could the Admin match the same student to two internships at once? If not, what should happen when the Admin tries?**

## Student — 2026-10-05 18:03

No an application can only have one active match at a time, meaning only one match with status pending or accepted. The admin can only create a new Match after the current one has been rejected

### Guide

That's a clear rule. Match will have at most one row per application with status `pending` or `accepted`, and new matches are allowed only after a rejection.

**Question 5: An Internship has `number of positions`. Suppose it has 2 positions and already has 2 accepted Matches. Can the Admin still match another application to it? Should the internship switch to `closed` automatically, and do pending Matches count against the positions?**

## Student — 2026-10-05 18:04

if the position has already been filled, it should be switched to closed

### Guide

Okay. When the number of accepted Matches reaches `number of positions`, the internship switches to `closed`, and the Admin can only match to `open` internships. You didn't say whether pending Matches count. I'll assume only **accepted** ones count, so pending Matches don't hold a position.

**Question 6 (the last one): Publish/Manage Internships lets a company edit or remove its internship. What should happen if a company tries to delete an internship that already has Match rows, especially a pending or accepted one?**

## Student — 2026-10-05 18:07

A company cannot delete an internship that has any match rows  because that would break the history the admin uses for re-matching. Instead, the company can close it by changing its status to closed. A closed internship stops getting new matches, but any pending match still stays in review aplication so the company can accept or reject that student, and accepted matches are kept as they are. Internships with no match rows can be deleted normally.

### Guide

_tool: Edit — c:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

Phase 3 is done. I added the model diagram (a Mermaid `erDiagram`) and your decisions to the **Model diagram** section of [docs/report.md](docs/report.md). It covers all six of your entities and their properties.

**Relationships in the model:**
- **User → Student and User → Company:** each profile belongs to exactly one User. Admins are Users with the admin role and no profile.
- **Company → Internship:** one-to-many.
- **Student → Application:** one-to-many.
- **Application → Match and Internship → Match:** both one-to-many, with the foreign keys on Match. This keeps the re-matching history.

**Business rules recorded:**
- An application can have only one active Match (`pending` or `accepted`) at a time.
- An internship closes automatically when its positions are filled.
- An internship with Match rows can only be closed, not deleted.

**Assumptions to check in Phase 4/5** (I didn't ask about these, so they're also listed in the report):
- Only accepted Matches count toward `number_of_positions`. You didn't say whether pending ones do.
- A student can have more than one Application over time.
- `Application.status` follows the current Match. When a company rejects, it goes back to `submitted`. It becomes `rejected` only when the Admin finds no suitable internship.

```text
Phase 3 done
Artefact: docs/report.md (Model diagram + Phase 3 decisions)
Base confidence: 0.65
Questions: 6/6
Suspicion: none
Skips: 0/3 used
Report: updated
```

Your progress is saved in `docs/report.md`, not only in this chat. Next, draw your wireframes and put the images in `docs/wireframes/`. Then open a **new chat** and paste:

```text
Use the student-build skill. Phase 4. Wireframe images are in docs/wireframes/.
```

## Student — 2026-10-12 02:35

can you add projects to the application model

### Guide

_tool: Edit — c:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

_tool: Edit — c:\Users\suare\OneDrive\Documents\GitHub\Comp3613_A1\docs\report.md_

I added `projects` to the Application entity in the model diagram in [docs/report.md](docs/report.md). I also added a line to the Phase 3 decisions noting that you added it after the first draft.

I'd already asked all 6 questions allowed for this phase, so I didn't ask what form `projects` should take. I treated it as **free text**, the same as `preferences`: the student writes about their relevant projects in one field.

If you want each project stored separately with its own details (a title, description or link, for example), it would need to be its own Project entity, with one Application having many Projects. Tell me which properties a project should have and I'll redraw the diagram that way.

Phase 3 is otherwise unchanged. Next, put your wireframe images in `docs/wireframes/`, open a new chat and paste:

```text
Use the student-build skill. Phase 4. Wireframe images are in docs/wireframes/.
```

